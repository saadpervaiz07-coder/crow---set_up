#include "mongoose.h"
#include <stdio.h>

static void fn(struct mg_connection *c, int ev, void *ev_data) {
  if (ev == MG_EV_HTTP_MSG) {
    struct mg_http_message *hm = (struct mg_http_message *) ev_data;

    // mg_vcmp use karein kyunki ye har version mein hota hai
    if (mg_vcmp(&hm->uri, "/api/hello") == 0) {
      mg_http_reply(c, 200, "Content-Type: application/json\r\n", 
                    "{\"status\": \"success\", \"message\": \"Bhai, Server Chal Gaya!\"}");
    } 
    else {
      struct mg_http_serve_opts opts = {.root_dir = "."}; 
      mg_http_serve_dir(c, hm, &opts);
    }
  }
}

int main(void) {
  struct mg_mgr mgr;
  mg_mgr_init(&mgr);
  
  if (mg_http_listen(&mgr, "http://0.0.0.0:8000", fn, NULL) == NULL) {
      printf("Error: Port 8000 occupied hai ya koi aur masla hai.\n");
      return 1;
  }
  
  printf("Server chal raha hai: http://localhost:8000\n");
  
  for (;;) mg_mgr_poll(&mgr, 1000); 
  
  mg_mgr_free(&mgr);
  return 0;
}


// #include "mongoose.h"

// // Yeh function har request (HTML load karna ho ya API) ko handle karega
// static void fn(struct mg_connection *c, int ev, void *ev_data) {
//   if (ev == MG_EV_HTTP_MSG) {
//     struct mg_http_message *hm = (struct mg_http_message *) ev_data;

//     // 1. Check karein agar request "/api/hello" ke liye hai
//     if (mg_http_match(hm->uri, mg_str("/api/hello"), NULL)) {
//       mg_http_reply(c, 200, "Content-Type: application/json\r\n", 
//                     "{\"status\": \"success\", \"message\": \"Mongoose Server is Live!\"}");
//     } 
//     // 2. Agar API nahi hai, toh current folder se HTML/CSS serve karein
//     else {
//       struct mg_http_serve_opts opts = {.root_dir = "."}; 
//       mg_http_serve_dir(c, hm, &opts);
//     }
//   }
// }

// int main(void) {
//   struct mg_mgr mgr;
//   mg_mgr_init(&mgr);                                      // Manager initialize karein
//   mg_http_listen(&mgr, "http://localhost:8000", fn, NULL); // Port 8000 par start karein
  
//   printf("Server chal raha hai: http://localhost:8000\n");
  
//   for (;;) mg_mgr_poll(&mgr, 1000);                       // Infinite loop
//   mg_mgr_free(&mgr);                                      // Cleanup
//   return 0;
// }